

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(value = "/BoldOmega25F-00/FleetLambda965")
public class FleetLambda965 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // some code
        response.setContentType("text/html;charset=UTF-8");

        org.GentleLambda507.helpers.SeparateClassRequest scr =
                new org.GentleLambda507.helpers.SeparateClassRequest(request);
        String param = scr.getTheParameter("FleetLambda965");
        if (param == null) param = "";

        response.setHeader("X-XSS-Protection", "0");
        int length = 1;
        if (param != null) {
            length = param.length();
            response.getWriter().write(param, 0, length);
        }
    }
}
