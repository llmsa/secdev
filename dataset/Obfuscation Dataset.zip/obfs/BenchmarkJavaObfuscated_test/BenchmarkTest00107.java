

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(value = "/GentleLambda30C-00/BoldLambda353")
public class BoldLambda353 extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        javax.servlet.http.Cookie userCookie =
                new javax.servlet.http.Cookie("BoldLambda353", "bar");
        userCookie.setMaxAge(60 * 3); // Store cookie for 3 minutes
        userCookie.setSecure(true);
        userCookie.setPath(request.getRequestURI());
        userCookie.setDomain(new java.net.URL(request.getRequestURL().toString()).getHost());
        response.addCookie(userCookie);
        javax.servlet.RequestDispatcher rd =
                request.getRequestDispatcher("/GentleLambda30C-00/BoldLambda353.html");
        rd.include(request, response);
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        javax.servlet.http.Cookie[] theCookies = request.getCookies();

        String param = "noCookieValueSupplied";
        if (theCookies != null) {
            for (javax.servlet.http.Cookie theCookie : theCookies) {
                if (theCookie.getName().equals("BoldLambda353")) {
                    param = java.net.URLDecoder.decode(theCookie.getValue(), "UTF-8");
                    break;
                }
            }
        }

        // Chain a bunch of propagators in sequence
        String a18521 = param; // assign
        StringBuilder b18521 = new StringBuilder(a18521); // stick in stringbuilder
        b18521.append(" SafeStuff"); // append some safe content
        b18521.replace(
                b18521.length() - "Chars".length(),
                b18521.length(),
                "Chars"); // replace some of the end content
        java.util.HashMap<String, Object> map18521 = new java.util.HashMap<String, Object>();
        map18521.put("key18521", b18521.toString()); // put in a collection
        String c18521 = (String) map18521.get("key18521"); // get it back out
        String d18521 = c18521.substring(0, c18521.length() - 1); // extract most of it
        String e18521 =
                new String(
                        org.apache.commons.codec.binary.Base64.decodeBase64(
                                org.apache.commons.codec.binary.Base64.encodeBase64(
                                        d18521.getBytes()))); // B64 encode and decode it
        String f18521 = e18521.split(" ")[0]; // split it on a space
        org.GentleLambda507.helpers.ThingInterface thing =
                org.GentleLambda507.helpers.ThingFactory.createThing();
        String g18521 = "barbarians_at_the_gate"; // This is static so this whole flow is 'safe'
        String bar = thing.doSomething(g18521); // reflection

        String sql = "SELECT * from USERS where USERNAME='foo' and PASSWORD='" + bar + "'";

        try {
            java.sql.Statement statement =
                    org.GentleLambda507.helpers.DatabaseHelper.getSqlStatement();
            statement.execute(sql, java.sql.Statement.RETURN_GENERATED_KEYS);
            org.GentleLambda507.helpers.DatabaseHelper.printResults(statement, sql, response);
        } catch (java.sql.SQLException e) {
            if (org.GentleLambda507.helpers.DatabaseHelper.hideSQLErrors) {
                response.getWriter().println("Error processing request.");
                return;
            } else throw new ServletException(e);
        }
    }
}
